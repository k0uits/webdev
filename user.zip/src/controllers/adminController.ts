import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import {
    getUsers,
    removeUserById,
    updateUserById,
    setPasswordById,
} from "../models/userModel";

/** petit helper: on récupère un id depuis params/body et on le force en string */
function getIdString(req: Request): string {
    const raw = (req.params as any).id ?? (req.body as any).id;
    // NE PAS caster en number, on garde tel quel et on stringifie
    return String(raw);
}

/** GET /admin/users — liste brute (JSON) */
export async function listAllUsers(_req: Request, res: Response) {
    const users = await getUsers();
    // on masque le hash par sécurité
    const safe = users.map(u => ({ ...u, password: undefined }));
    return res.json(safe);
}

/** DELETE /admin/users/:id — suppression d’un compte */
export async function adminDeleteUser(req: Request, res: Response) {
    try {
        const id = getIdString(req);
        if (!id) return res.status(400).json({ message: "id requis" });

        const ok = await removeUserById(id); // <-- string
        if (!ok) return res.status(404).json({ message: "Utilisateur introuvable" });

        return res.status(200).json({ message: "Utilisateur supprimé", id });
    } catch (e) {
        console.error("adminDeleteUser:", e);
        return res.status(500).json({ message: "Erreur suppression utilisateur" });
    }
}

/** PATCH /admin/users/:id — mise à jour nom/email/role */
export async function adminUpdateUser(req: Request, res: Response) {
    try {
        const id = getIdString(req);
        if (!id) return res.status(400).json({ message: "id requis" });

        const { nom, email, role } = req.body as {
            nom?: string;
            email?: string;
            role?: "user" | "admin";
        };

        const updated = await updateUserById(id, {
            nom: nom?.trim(),
            email: email?.trim(),
            role,
        });
        if (!updated) return res.status(404).json({ message: "Utilisateur introuvable" });

        // on masque le hash
        const safe = { ...updated, password: undefined };
        return res.status(200).json({ message: "Profil mis à jour", user: safe });
    } catch (e) {
        console.error("adminUpdateUser:", e);
        return res.status(500).json({ message: "Erreur mise à jour" });
    }
}

/** POST /admin/users/:id/password — reset du mot de passe par un admin */
export async function adminSetPassword(req: Request, res: Response) {
    try {
        const id = getIdString(req);
        if (!id) return res.status(400).json({ message: "id requis" });

        const { newPassword } = req.body as { newPassword?: string };
        if (!newPassword || newPassword.length < 6) {
            return res.status(400).json({ message: "Mot de passe trop court (≥ 6 caractères)" });
        }

        const hash = await bcrypt.hash(newPassword, 10);
        const ok = await setPasswordById(id, hash); // <-- string
        if (!ok) return res.status(404).json({ message: "Utilisateur introuvable" });

        return res.status(200).json({ message: "Mot de passe mis à jour ✅" });
    } catch (e) {
        console.error("adminSetPassword:", e);
        return res.status(500).json({ message: "Erreur mise à jour du mot de passe" });
    }
}

export const renderAdminPage = (req: any, res: any) => {
    return res.render("admin", { user: req.user || null });
};

export const deleteUser = adminDeleteUser;
export const updateUser = adminUpdateUser;
export const updateUserPassword = adminSetPassword;