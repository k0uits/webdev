import fs from "fs";
import path from "path";

export interface User {
  id: string;                 // unifié en string (cohérent avec register)
  nom: string;
  email: string;
  password: string;           // hashé avec bcrypt
  role?: "user" | "admin";
  points?: number;            // par défaut 0
}

const usersFilePath = path.join(__dirname, "../../data/users.json");

function ensureFile() {
  const dir = path.dirname(usersFilePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(usersFilePath)) fs.writeFileSync(usersFilePath, "[]", "utf-8");
}

export async function getUsers(): Promise<User[]> {
  ensureFile();
  const raw = await fs.promises.readFile(usersFilePath, "utf-8");
  try {
    const arr: any[] = raw.trim() ? JSON.parse(raw) : [];
    // Normalise: id en string, points en number
    return arr.map(u => ({
      ...u,
      id: String(u.id),
      points: Number(u.points || 0),
    })) as User[];
  } catch {
    await fs.promises.writeFile(usersFilePath, "[]", "utf-8");
    return [];
  }
}

export async function saveUsers(list: User[]): Promise<void> {
  ensureFile();
  const norm = list.map(u => ({
    ...u,
    id: String(u.id),
    points: Number(u.points || 0),
  }));
  await fs.promises.writeFile(usersFilePath, JSON.stringify(norm, null, 2), "utf-8");
}

export async function findUserById(id: string): Promise<User | undefined> {
  const users = await getUsers();
  return users.find(u => String(u.id) === String(id));
}

export async function findUserByEmail(email: string): Promise<User | undefined> {
  const users = await getUsers();
  return users.find(u => (u.email || "").toLowerCase() === (email || "").toLowerCase());
}

export async function addUser(newUser: User): Promise<User> {
  const users = await getUsers();
  users.push({
    ...newUser,
    id: String(newUser.id),
    points: Number(newUser.points || 0),
  });
  await saveUsers(users);
  return newUser;
}

export async function updateUserById(
  id: string,
  patch: Partial<Pick<User, "nom" | "email" | "role">>
): Promise<User | null> {
  const users = await getUsers();
  const idx = users.findIndex(u => String(u.id) === String(id));
  if (idx === -1) return null;

  if (patch.nom !== undefined) users[idx].nom = patch.nom;
  if (patch.email !== undefined) users[idx].email = patch.email;
  if (patch.role === "user" || patch.role === "admin") users[idx].role = patch.role;

  await saveUsers(users);
  return users[idx];
}

export async function updateUserFields(
  id: string,
  nom: string,
  email: string,
  role: "user" | "admin" = "user"
): Promise<boolean> {
  const users = await getUsers();
  const idx = users.findIndex(u => String(u.id) === String(id));
  if (idx === -1) return false;

  users[idx].nom = nom;
  users[idx].email = email;
  users[idx].role = role;

  await saveUsers(users);
  return true;
}

export async function setPasswordById(id: string, passwordHash: string): Promise<boolean> {
  const users = await getUsers();
  const idx = users.findIndex(u => String(u.id) === String(id));
  if (idx === -1) return false;
  users[idx].password = passwordHash;
  await saveUsers(users);
  return true;
}

export async function removeUserById(id: string): Promise<boolean> {
  const users = await getUsers();
  const next = users.filter(u => String(u.id) !== String(id));
  if (next.length === users.length) return false;
  await saveUsers(next);
  return true;
}

export function readUsers(): User[] {
  ensureFile();
  const raw = fs.readFileSync(usersFilePath, "utf-8");
  try {
    const arr: any[] = raw.trim() ? JSON.parse(raw) : [];
    // normalise le champ points
    return arr.map(u => ({ ...u, points: Number(u.points || 0) }));
  } catch {
    fs.writeFileSync(usersFilePath, "[]", "utf-8");
    return [];
  }
}

/** Incrémente les points et renvoie l'utilisateur mis à jour (sync) */
export function addPoints(userId: string | number, delta: number): User | null {
  const users = readUsers();
  const idx = users.findIndex(u => String(u.id) === String(userId));
  if (idx < 0) return null;

  const before = Number(users[idx].points || 0);
  users[idx].points = before + Number(delta || 0);

  // on sauve en synchrone pour rester simple/cohérent
  fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2), "utf-8");
  return users[idx];
}